package com.example.demo.api;

import com.example.demo.service.NotificationService;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("api/send/notification")
@RestController
public class SendController {

    private NotificationService notservice;

    @Autowired
    public SendController(NotificationService notservice){

        this.notservice=notservice;
    }

    @PostMapping(path="{id}/email")
    public void sendByEmail(@RequestBody String placeholders,
                            @RequestBody String Email,
                            @PathVariable("id") int id)
    {
        notservice.sendByEmail(placeholders,Email,id);
    }
    @PostMapping(path="{id}/sms")
    public void sendBySMS(@RequestBody String placeholders,
                          @RequestBody  String PhoneNumber,
                          @PathVariable("id") int id)
    {
        notservice.sendBySMS(placeholders,PhoneNumber,id);
    }
}
