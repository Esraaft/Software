package com.example.demo.dao;

import com.example.demo.model.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;

@Repository("memory")
public class NotificationMemory implements INotifications {

    String content;
    private ArrayList<NotificationModule> NotificationModules=new ArrayList<NotificationModule>();
    private ArrayList<String>QUEUEING =new ArrayList<String>();

    @Override
    public void addTemplate(NotificationModule newNotificationModule){
    	NotificationModules.add(newNotificationModule);
    }
    @Override
    public void sendTemplate( String placeholders ,int id){
        Optional<NotificationModule> notificationMaybe=selectNotificationByID(id);
        if(!notificationMaybe.isEmpty()) {
            String []placeholderArray = placeholders.split(" ");
            String sendContent =notificationMaybe.get().getContent();
            int index=sendContent.indexOf("**");
            int i=0;
            while(index>=0&&i<placeholderArray.length){
                sendContent=sendContent.substring(0,index)+placeholderArray[i]+sendContent.substring(index+2,sendContent.length());
                if(!sendContent.contains("**"))
                    break;
                index=sendContent.indexOf("**");
                i++;
            }
                  QUEUEING.add(sendContent);
            System.out.println(QUEUEING);
        }
    }

    public int getSize() {
        return NotificationModules.size();
    }

    /*
    public NotificationModule getTemplate(int ID ) {
        return NotificatonModules.get(ID);
    }*/
    public Optional<NotificationModule> selectNotificationByID(int id) {
		return NotificationModules.stream().filter(NotificationModule -> NotificationModule.getID()==(id)).findFirst();
	}

    @Override
    public  ArrayList<NotificationModule> getAllTemplates() {
        return NotificationModules;

    }



    @Override
    public boolean deleteTemplate(int id) {
    	Optional<NotificationModule> notificationMaybe=selectNotificationByID(id);
		if(notificationMaybe.isEmpty()) {
			return false;
		}
		NotificationModules.remove(notificationMaybe.get());
		return true;
    }

    @Override
    public void updateTemplate(int id,NotificationModule newNotificationModule){
    	Optional<NotificationModule> notificationMaybe=selectNotificationByID(id);
		if(!notificationMaybe.isEmpty()) {
			//make new template with the old id
			NotificationModule temp=new NotificationModule(newNotificationModule.getContent(),newNotificationModule.getChannel()
					,newNotificationModule.getLanguage(),newNotificationModule.getSubject(),id);
			NotificationModules.set(NotificationModules.indexOf(notificationMaybe.get()),temp);
		}
    }


}

