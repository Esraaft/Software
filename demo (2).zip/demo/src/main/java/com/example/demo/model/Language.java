package com.example.demo.model;

public enum Language {
    Arabic, English, French, German, Italian;

    public String toString() {
        switch (this) {
            case Arabic:
                return "Arabic";
            case English:
                return "English";
            case French:
                return "French";
            case German:
                return "German";
            case Italian:
                return "Italian";
            default:
                return "English";
        }

    }
}