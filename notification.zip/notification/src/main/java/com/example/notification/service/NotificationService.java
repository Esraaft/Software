package com.example.notification.service;

import com.example.notification.interfaces.INotifications;
import com.example.notification.model.NotificationModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class NotificationService {

    private INotifications inotification ;
    private NotificationModule notification;

@Autowired
    public NotificationService(@Qualifier ("memory") INotifications inotification){
        this.inotification=inotification;
    }

    public void Create()
    {
        inotification.addTemplate(notification);
    }

    public void Update(){
        inotification.updateTemplate(notification);
    }

    public ArrayList<NotificationModule> Read(){
        return inotification.getAllTemplates();
    }

    public void Delete()
    {
        inotification.deleteTemplate(notification.getID());
    }

}
