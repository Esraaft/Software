package com.example.notification.api;

import com.example.notification.model.NotificationModule;
import com.example.notification.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping ("api/v1/Notification")
@RestController
public class NotificationController {

    private NotificationService notservice;

    @Autowired
    public NotificationController(NotificationService notservice){

        this.notservice=notservice;
    }

    @PostMapping
    public void Create(@RequestBody  NotificationModule not)
    {
        notservice.Create();
    }

    @GetMapping (path={"id"})
    public void Update(@PathVariable int id)
    {
        notservice.Update();
    }

    @GetMapping (path={"id"})
    public void delete(@PathVariable int id)
    {
        notservice.Delete();
    }

    @GetMapping
    public void read()
    {
        notservice.Read();
    }

}
