package com.example.notification.interfaces;


import com.example.notification.model.NotificationModule;

import java.util.ArrayList;


    public interface  INotifications{

        public ArrayList<NotificationModule> getAllTemplates();

        public void addTemplate(NotificationModule newNotificationModule);
        public void updateTemplate(NotificationModule existinfNotificationModule);
        public NotificationModule getTemplate(int ID);
        public boolean deleteTemplate(int ID);

    }