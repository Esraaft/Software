package com.example.notification.model;


public enum Channel {
    SMS,email;
    public String toString() {
        switch(this)
        {
            case SMS: return "SMS";
            default: return "email";
        }
    }
}