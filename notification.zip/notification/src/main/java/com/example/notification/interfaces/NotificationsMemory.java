package com.example.notification.interfaces;

import com.example.notification.model.*;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository ("memory")
public class NotificationsMemory implements INotifications {

    Content content;
    private ArrayList<NotificationModule> NotificatonModules=new ArrayList<NotificationModule>();



    @Override
    public void addTemplate(NotificationModule newNotificationModule){

        NotificatonModules.add(new NotificationModule(
                content.getTemplate(),
                newNotificationModule.getChannel(),
                newNotificationModule.getLanguage(),
                newNotificationModule.getSubject(),
                newNotificationModule.getID()));
    }

    public int getSize() {
        return NotificatonModules.size();
    }


    public NotificationModule getTemplate(int ID ) {
        return NotificatonModules.get(ID);
    }

    @Override
    public  ArrayList<NotificationModule> getAllTemplates() {
        return NotificatonModules;

    }



    @Override
    public boolean deleteTemplate(int ID) {
        if(NotificatonModules.contains(ID)) {
            NotificatonModules.remove(ID);
            return true;
        }
        return false;
    }

    @Override
    public void updateTemplate(NotificationModule existingNotificationModule) {
     return;

    }


}