package com.example.demo.dao;

import com.example.demo.model.NotificationModule;

import java.util.ArrayList;


    public interface  INotifications{

        public ArrayList<NotificationModule> getAllTemplates();
        public void addTemplate(NotificationModule newNotificationModule);
        public void updateTemplate(int id,NotificationModule newNotificationModule);
        public NotificationModule selectNotificationByID(int id);
        public boolean deleteTemplate(int ID);
        public void sendTemplateByEmail( String placeholders ,int id);
        public void sendTemplateBySMS( String placeholders,int id);

    }