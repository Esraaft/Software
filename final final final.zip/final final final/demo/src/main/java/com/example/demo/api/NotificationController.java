package com.example.demo.api;

import com.example.demo.model.NotificationModule;
import com.example.demo.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RequestMapping("api/notification")
@RestController
public class NotificationController {

    private NotificationService notservice;

    @Autowired
    public NotificationController(NotificationService notservice){

        this.notservice=notservice;
    }

    @PostMapping
    public void Create(@RequestBody  NotificationModule not)
    {
        notservice.Create(not);
    }
    
    @GetMapping
    public ArrayList<NotificationModule> read()
    {
        return notservice.Read();
    }
    
    @GetMapping(path="{id}")
	public NotificationModule getNotificationByID(@PathVariable("id") int id) {
		return notservice.getNotificationByID(id);
	}
    
    @PutMapping(path="{id}")
    public void Update(@PathVariable("id") int id,@RequestBody NotificationModule notificationModule)
    {
        notservice.Update(id,notificationModule);
    }

    @DeleteMapping(path="{id}")
    public void delete(@PathVariable("id") int id)
    {
        notservice.Delete(id);
    }

}
