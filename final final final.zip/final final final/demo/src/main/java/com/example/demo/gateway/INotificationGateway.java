package com.example.demo.gateway;

public interface INotificationGateway {

    public void SendNotification();
    public void Print();
}
