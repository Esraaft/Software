package com.example.demo.service;

import com.example.demo.dao.INotifications;
import com.example.demo.model.NotificationModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class NotificationService {

    private final INotifications inotification ;


@Autowired
    public NotificationService(@Qualifier("Database") INotifications inotification){
        this.inotification=inotification;
    }

    public void Create(NotificationModule notification)
    {
        inotification.addTemplate(notification);
    }
    public NotificationModule getNotificationByID(int id){
		return inotification.selectNotificationByID(id);
	}
    public void Update(int id,NotificationModule notification){
        inotification.updateTemplate(id,notification);
    }

    public ArrayList<NotificationModule> Read(){
        return inotification.getAllTemplates();
    }

    public void Delete(int id)
    {
        inotification.deleteTemplate(id);
    }
    public void sendByEmail( String placeholders ,int id){
        inotification.sendTemplateByEmail(placeholders,id);

    }
    public void sendBySMS( String placeholders ,int id){
        inotification.sendTemplateBySMS(placeholders,id);
    }
}

