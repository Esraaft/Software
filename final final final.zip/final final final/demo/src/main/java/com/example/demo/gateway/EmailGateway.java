package com.example.demo.gateway;

import com.example.demo.dao.NotificationDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmailGateway implements INotificationGateway {
    private static final String USERNAME="root";
    private static final String PASSWORD="Esraa0628";
    private static final String CONNECTION="jdbc:mysql://localhost:3306/NotificationMemory?autoReconnect=true&useSSL=false";
    Connection connection=null;
    String content;

    public EmailGateway()
    {
        try {
            connection=(Connection) DriverManager.getConnection(CONNECTION,USERNAME,PASSWORD);

        } catch (SQLException ex) {
            System.err.println(ex);
            Logger.getLogger(NotificationDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void SendNotification() {
        ArrayList<Integer> IDs=new ArrayList<Integer>();
        String update="UPDATE EmailQUEUEING SET EStatus=? WHERE EmailID=?";

        try {
            Statement stmt=connection.createStatement();
            ResultSet rs= null;
            rs = stmt.executeQuery("select * from EmailQUEUEING");
            while(rs.next())
            {
                int ID=rs.getInt(4);
                IDs.add(ID);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        for(int i=0;i<IDs.size();i++)
        {
            Random rd = new Random();
            if(rd.nextBoolean())
            {
                try {
                    PreparedStatement preparedStmt = connection.prepareStatement(update);
                    int id=IDs.get(i);
                    preparedStmt.setString(1, "success");
                    preparedStmt.setInt   (2, id);
                    preparedStmt.executeUpdate();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
            else
            {
                try {
                    PreparedStatement preparedStmt = connection.prepareStatement(update);
                    int id=IDs.get(i);
                    preparedStmt.setString(1, "failure");
                    preparedStmt.setInt   (2, id);
                    preparedStmt.executeUpdate();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }

    }

    @Override
    public void Print() {
        try {
            Statement stmt=connection.createStatement();
            ResultSet rs= null;
            rs = stmt.executeQuery("select * from EmailQUEUEING");
            while(rs.next())
            {
                if(rs.getString(3).equalsIgnoreCase("success")){
                System.out.println("Email");
                System.out.println(rs.getString(1)+" "+rs.getString(2));}
                System.out.println();
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
