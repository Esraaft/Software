import com.example.demo.gateway.EmailGateway;
import com.example.demo.gateway.SMSGateway;


public class TestSend {

    public static void main(String[] args) {
        EmailGateway e1=new EmailGateway();
        SMSGateway s1=new SMSGateway();
        //e1.SendNotification();
        //s1.SendNotification();
        e1.Print();
        s1.Print();
    }
}
