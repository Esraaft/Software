package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NotificationModule {
    private final String content;
    private final Language language;
    private final String subject;
    private final int ID;


   // public NotificationModule(){}
    public NotificationModule(
                             @JsonProperty ("content")String content,
                             @JsonProperty ("language")String language,
                              @JsonProperty ("subject")String subject,
                              @JsonProperty ("id")int ID){

		this.content=content;
        this.subject=subject;
        this.ID=ID;

        switch(language)
        {
            case "Arabic":  this.language=Language.Arabic;break;
            case "English":  this.language=Language.English;break;
            case "French":  this.language=Language.French;break;
            case "German":	this.language=Language.German;break;
            case "Italian": this.language=Language.Italian;break;
            default: 	this.language=Language.English;
        }
    }
  
    public String getContent() {
        return content;
    }
    public String getLanguage() {
        return language.toString();
    }
    public String getSubject() {
        return subject;
    }
    public int getID() {
        return ID;
    }

	
   
}
