CREATE DATABASE NotificationMemory;

CREATE TABLE Template (
	Content TEXT,
    Language varchar(255),
    Subject varchar(255),
    TemplateID int NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (TemplateID)
);
insert into Template(Content,Language,Subject) values("Hello ** your ** is ready","English","purchase");
insert into Template(Content,Language,Subject) values("Hello ** you must deliver you work","French","work");
select * from EmailQUEUEING;

CREATE TABLE EmailQUEUEING (
	Content TEXT,
    Email varchar(255),
    EStatus varchar(255) DEFAULT 'Waiting'
);

CREATE TABLE SMSQUEUEING(
	Content TEXT,
    PhoneNumber varchar(255),
    SStatus varchar(255) DEFAULT 'Waiting'
);
