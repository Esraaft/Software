package com.example.demo.dao;

import com.example.demo.model.NotificationModule;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

@Repository("Database")
public class NotificationDatabase implements INotifications {

    private static final String USERNAME="root";
    private static final String PASSWORD="Esraa0628";
    private static final String CONNECTION="jdbc:mysql://localhost:3306/NotificationMemory?autoReconnect=true&useSSL=false";
    Connection connection=null;
    String content;

    public NotificationDatabase()
    {
        try {
            connection=(Connection) DriverManager.getConnection(CONNECTION,USERNAME,PASSWORD);

        } catch (SQLException ex) {
            System.err.println(ex);
            Logger.getLogger(NotificationDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void addTemplate(NotificationModule newNotificationModule){
        String INSERT = "INSERT INTO TEMPLATE (Content, Language, Subject) VALUES (?,?,?)";

        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(INSERT);
            preparedStatement.setString(1, newNotificationModule.getContent());
            preparedStatement.setString(2, newNotificationModule.getLanguage());
            preparedStatement.setString(3, newNotificationModule.getSubject());
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(NotificationDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public int getSize() {
        int count=0;
        try {
            Statement stmt=connection.createStatement();
            ResultSet rs= null;
            rs = stmt.executeQuery("select * from Template");
            while(rs.next())
            {
                count++;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return count;
    }

    /*
    public NotificationModule getTemplate(int ID ) {
        return NotificatonModules.get(ID);
    }*/
    public NotificationModule selectNotificationByID(int id) {
        NotificationModule newNotificationModule = null;
        try {
            Statement stmt=connection.createStatement();
            ResultSet rs= null;
            rs = stmt.executeQuery("select * from Template WHERE TemplateID="+id+";");
            while(rs.next())
            {
                newNotificationModule=new NotificationModule(rs.getString(1),rs.getString(2),
                        rs.getString(3),rs.getInt(4));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
		return newNotificationModule;
	}

    @Override
    public  ArrayList<NotificationModule> getAllTemplates() {
        ArrayList<NotificationModule> NotificationModules=new ArrayList<NotificationModule>();
        try {
            Statement stmt=connection.createStatement();
            ResultSet rs= null;
            rs = stmt.executeQuery("select * from Template");
            while(rs.next())
            {
                NotificationModule newNotificationModule=new NotificationModule(rs.getString(1),rs.getString(2),
                        rs.getString(3),rs.getInt(4));
                NotificationModules.add(newNotificationModule);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return NotificationModules;
    }



    @Override
    public boolean deleteTemplate(int id) {

        NotificationModule notificationMaybe=selectNotificationByID(id);
        if(notificationMaybe==null) {
            return false;
        }
        try {
            Statement stmt=connection.createStatement();
            int rs = stmt.executeUpdate("delete from Template where TemplateID="+id);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
		return true;
    }

    @Override
    public void updateTemplate(int id,NotificationModule newNotificationModule){
    	NotificationModule notificationMaybe=selectNotificationByID(id);
		if(!(notificationMaybe==null)) {
			//make new template with the old id
            String UPDATE= "UPDATE TEMPLATE set Content=?, Language=?, Subject=? WHERE TemplateID=?; ";

            PreparedStatement preparedStatement = null;
            try {
                preparedStatement = connection.prepareStatement(UPDATE);
                preparedStatement.setString(1, newNotificationModule.getContent());
                preparedStatement.setString(2, newNotificationModule.getLanguage());
                preparedStatement.setString(3, newNotificationModule.getSubject());
                preparedStatement.setInt(4, id);
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(NotificationDatabase.class.getName()).log(Level.SEVERE, null, ex);
            }
		}
    }


    public void sendTemplateByEmail( String placeholders,int id){
        NotificationModule notificationMaybe=selectNotificationByID(id);
        String Email=placeholders.substring(placeholders.lastIndexOf(" ")+1);
        placeholders=placeholders.substring(0, placeholders.lastIndexOf(" "));
        if(!(notificationMaybe==null)) {
            String []placeholderArray = placeholders.split(" ");
            String sendContent =notificationMaybe.getContent();
            int index=sendContent.indexOf("**");
            int i=0;
            while(index>=0&&i<placeholderArray.length){
                sendContent=sendContent.substring(0,index)+placeholderArray[i]+sendContent.substring(index+2,sendContent.length());
                if(!sendContent.contains("**"))
                    break;
                index=sendContent.indexOf("**");
                i++;
            }
            String INSERT = "INSERT INTO EmailQUEUEING (Content,Email) VALUES (?,?)";

            PreparedStatement preparedStatement = null;
            try {
                preparedStatement = connection.prepareStatement(INSERT);
                preparedStatement.setString(1, sendContent);
                preparedStatement.setString(2, Email);
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(NotificationDatabase.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void sendTemplateBySMS( String placeholders,int id){
        NotificationModule notificationMaybe=selectNotificationByID(id);
        String PhoneNumber= placeholders.substring(placeholders.lastIndexOf(" ")+1);
        placeholders=placeholders.substring(0, placeholders.lastIndexOf(" "));
        if(!(notificationMaybe==null)) {
            String []placeholderArray = placeholders.split(" ");
            String sendContent =notificationMaybe.getContent();
            int index=sendContent.indexOf("**");
            int i=0;
            while(index>=0&&i<placeholderArray.length){
                sendContent=sendContent.substring(0,index)+placeholderArray[i]+sendContent.substring(index+2,sendContent.length());
                if(!sendContent.contains("**"))
                    break;
                index=sendContent.indexOf("**");
                i++;
            }
            String INSERT = "INSERT INTO SMSQUEUEING (Content,PhoneNumber) VALUES (?,?)";

            PreparedStatement preparedStatement = null;
            try {
                preparedStatement = connection.prepareStatement(INSERT);
                preparedStatement.setString(1, sendContent);
                preparedStatement.setString(2, PhoneNumber);
                preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(NotificationDatabase.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}

