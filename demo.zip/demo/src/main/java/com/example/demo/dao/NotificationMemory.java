package com.example.demo.dao;

import com.example.demo.model.*;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;

@Repository("memory")
public class NotificationMemory implements INotifications {

    String content;
    private ArrayList<NotificationModule> NotificationModules=new ArrayList<NotificationModule>();


    @Override
    public void addTemplate(NotificationModule newNotificationModule){
    	NotificationModules.add(newNotificationModule);
    }

    public int getSize() {
        return NotificationModules.size();
    }

    /*
    public NotificationModule getTemplate(int ID ) {
        return NotificatonModules.get(ID);
    }*/
    public Optional<NotificationModule> selectNotificationByID(int id) {
		return NotificationModules.stream().filter(NotificationModule -> NotificationModule.getID()==(id)).findFirst();
	}

    @Override
    public  ArrayList<NotificationModule> getAllTemplates() {
        return NotificationModules;

    }



    @Override
    public boolean deleteTemplate(int id) {
    	Optional<NotificationModule> notificationMaybe=selectNotificationByID(id);
		if(notificationMaybe.isEmpty()) {
			return false;
		}
		NotificationModules.remove(notificationMaybe.get());
		return true;
    }

    @Override
    public void updateTemplate(int id,NotificationModule newNotificationModule){
    	Optional<NotificationModule> notificationMaybe=selectNotificationByID(id);
		if(!notificationMaybe.isEmpty()) {
			NotificationModules.set(NotificationModules.indexOf(notificationMaybe),newNotificationModule);
		}
    }


}

