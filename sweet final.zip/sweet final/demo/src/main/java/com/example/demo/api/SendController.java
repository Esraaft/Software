package com.example.demo.api;

import com.example.demo.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("api/send/person")
@RestController
public class SendController {

    private NotificationService notservice;

    @Autowired
    public SendController(NotificationService notservice){

        this.notservice=notservice;
    }

    @PostMapping(path="{id}/email")
    public void sendByEmail(@RequestBody String placeholders, @PathVariable("id") int id)
    {
        notservice.sendByEmail(placeholders,id);
    }
    @PostMapping(path="{id}/sms")
    public void sendBySMS(@RequestBody String placeholders, @PathVariable("id") int id)
    {
        notservice.sendBySMS(placeholders,id);
    }
}
