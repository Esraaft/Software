CREATE DATABASE NotificationMemory;

CREATE TABLE Template (
	Content TEXT,
    Language varchar(255),
    Subject varchar(255),
    TemplateID int,
    PRIMARY KEY (TemplateID)
);
select * from EmailQUEUEING;
CREATE TABLE EmailQUEUEING (
	Content TEXT
);

CREATE TABLE SMSQUEUEING(
	Content TEXT
);