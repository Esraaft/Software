package com.example.demo.dao;

import com.example.demo.model.NotificationModule;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.Optional;


    public interface  INotifications{

        public void sendTemplate( String placeholders, int id);
        public Optional<NotificationModule> selectNotificationByID(int id);

        public ArrayList<NotificationModule> getAllTemplates();

    }