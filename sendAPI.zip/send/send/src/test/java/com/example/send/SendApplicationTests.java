package com.example.send;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SendApplicationTests {

	@Test
	void contextLoads() {
	}

}
